<a href="https://aimeos.org/">
    <img src="https://aimeos.org/fileadmin/template/icons/logo.png" alt="Aimeos logo" title="Aimeos" align="right" height="60" />
</a>

# Aimeos JQAdm admin interface

[![Build Status](https://travis-ci.org/aimeos/ai-admin-jqadm.png?branch=master)](https://travis-ci.org/aimeos/ai-admin-jqadm)
[![Coverage Status](https://coveralls.io/repos/aimeos/ai-admin-jqadm/badge.svg?branch=master)](https://coveralls.io/r/aimeos/ai-admin-jqadm?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/aimeos/ai-admin-jqadm/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/aimeos/ai-admin-jqadm/?branch=master)
[![License](https://poser.pugx.org/aimeos/ai-admin-jqadm/license.svg)](https://packagist.org/packages/aimeos/ai-admin-jqadm)

JQuery and Bootstrap based admin interface for Aimeos

[![Aimeos demo](https://aimeos.org/fileadmin/aimeos.org/images/aimeos-backend.png)](http://admin.demo.aimeos.org/)
